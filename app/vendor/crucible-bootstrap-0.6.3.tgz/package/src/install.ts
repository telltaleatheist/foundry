/**
 * `install()` — this host has a Crucible, at the release the app named, with
 * the job types it asked for, running as this machine's service.
 *
 * The sequence is `steps.ts`'s (PHASE14-ENVPACKS.md section 4), and this file
 * WALKS that list rather than restating it, so the generated `install.sh`
 * cannot describe a different install from the one an app performs:
 *
 *   host-facts       CRUCIBLE_HOME, the guest user, free disk, curl/tar/zstd
 *   server-pack      download + verify + unpack the release's server pack into
 *                    <CRUCIBLE_HOME>/server — the interpreter comes WITH it
 *   init             <server>/bin/crucible init --token <minted here> --enable-<type>…
 *                    SKIPPED when a config already exists (its token is kept)
 *   install-<type>   <server>/bin/crucible install <type>
 *   service-install  <server>/bin/crucible service install
 *   linger           WSL only: `loginctl enable-linger <guest user>` as root —
 *                    which since PHASE15 means the HOST runs it, never this file
 *   capability-write <server>/bin/crucible capability --write
 *
 * **There is no conda step and no pip step.** A fresh machine has no Python at
 * all and does not need one: the server pack is a relocatable CPython with the
 * crucible wheel already installed in it (PHASE14 section 1). `release` — a
 * version string — replaced `wheel` and the conda options, and it defaults to
 * this package's own version, which is the one legitimate default in here: the
 * bootstrapper ships AT the server's version, so "which release" is not a
 * question anybody has to answer.
 *
 * Pulls are NOT part of this: weights are the app's, later, per model.
 *
 * The token is minted on the client — `crucible init --token` — so the app that
 * installed the server already holds what `readLocalConfig()` would read back.
 * It is never logged: the argv reported for the init step spells it
 * `<redacted>`, and `onLine` only ever sees what the step printed.
 *
 * Every step's stdout and stderr stream to `onLine` as they arrive. A failing
 * step stops the sequence with a {@link BootstrapStepFailed} naming the step,
 * carrying the tail, and listing the steps that finished — what they did is on
 * disk and stays there (ARCHITECTURE.md R6).
 *
 * **ON WINDOWS NONE OF THAT HAPPENS HERE** (PHASE15-HOST.md section 4.3). The
 * sequence has ONE implementation and it is the host's: `crucible host`, the
 * Windows-native tray process, walks the state table and the step list and
 * raises the UAC prompts a WSL install needs. (It has no window of its own —
 * 4.7: its UI is the tray menu and the operator page.) So on win32 this
 * function is two branches and nothing else —
 *
 *   host installed?  ask it (`requestHostInstall`) and relay its events
 *                    through the SAME `onLine`/`onStep` this function was given
 *   host absent?     `host_not_installed`, carrying the `irm … | iex` line
 *
 * — and the walk below is reached only on linux and darwin, where the machine
 * IS the server and there is no host to ask.
 */
import { randomBytes } from 'node:crypto';

import { readLocalConfig, type LocalConfig } from './config.js';
import { backendFor, envpacksUrl, type PackBackend } from './envpacks.js';
import { BootstrapRefusal, BootstrapStepFailed } from './errors.js';
import { hostInstallCommand, hostInstalled, hostPackDir, requestHostInstall, type HostEvent, type HostFetch } from './hostdoor.js';
import { ensureLinger } from './linger.js';
import { fetchManifest, installPack, probeGuest, refuseMissingTools, SERVER_SUBDIR } from './pack.js';
import { processRunner, type OutputStream, type Runner } from './runner.js';
import { installSteps, renderArgv, type RefName, type StepPlan } from './steps.js';
import { describeTarget, resolveTarget, streamOn, type Target } from './target.js';
import { BOOTSTRAP_VERSION } from './version.js';

/** The job types `crucible init --enable-<type>` knows, in the order the CLI lists them. */
export const JOB_TYPES = ['echo', 'llm', 'asr', 'tts', 'align', 'rvc', 'denoise'] as const;
export type JobType = (typeof JOB_TYPES)[number];

/** The job types `crucible install <type>` has an installer for (`cli.INSTALLABLE_JOB_TYPES`). */
export const INSTALLABLE_JOB_TYPES: readonly JobType[] = ['llm', 'tts', 'asr', 'align', 'rvc'];

/**
 * One job type to enable. `tts` must say which narrator engine, because
 * cuda-linux has one env per engine and `crucible install tts` refuses without
 * it; a bare `'tts'` is refused here by name for the same reason.
 */
export type JobTypeRequest = Exclude<JobType, 'tts'> | { type: 'tts'; narratorEngine: string };

export interface InstallTimeouts {
  /** Every `crucible` verb that builds nothing, and the host probe. */
  quickMs: number;
  /** The server pack: a multi-gigabyte download over somebody's home line. */
  packMs: number;
  /** `crucible install <type>`, which downloads a job env pack. */
  envMs: number;
}

export const DEFAULT_INSTALL_TIMEOUTS: InstallTimeouts = {
  quickMs: 5 * 60_000,
  packMs: 120 * 60_000,
  envMs: 120 * 60_000,
};

export interface InstallOptions {
  /**
   * **No longer read by `install()`.** Which distro a Windows Crucible goes
   * into is the HOST's answer now (PHASE15 4.3): it owns the `crucible` distro
   * and imports it itself, so there is nothing for an app to choose and
   * nothing to send over the door. Kept on the interface because
   * `readLocalConfig()` and `detectHost()` still take it and callers pass one
   * object to all three.
   */
  distro?: string;
  /** Same: the host resolves the distro. See {@link InstallOptions.distro}. */
  exact?: boolean;
  jobTypes: readonly JobTypeRequest[];
  /** `CRUCIBLE_HOME` for every `crucible` verb, as the target spells it. Omit for the server's default. */
  home?: string;
  /**
   * Which release's packs to install. Defaults to {@link BOOTSTRAP_VERSION} —
   * the bootstrapper ships at the server's version, so the default IS the
   * answer rather than a guess at one.
   */
  release?: string;
  /** Every line a step prints, as it prints it. */
  onLine: (line: string, stream: OutputStream, step: string) => void;
  /** Optional: a step beginning, finishing, or being skipped. */
  onStep?: (step: InstallStep) => void;
  /** What `crucible init` should bind. Omit for the server's own defaults (127.0.0.1:7100). */
  bind?: { host?: string; port?: number };
  timeouts?: Partial<InstallTimeouts>;
  /**
   * win32 only: every event the host's door sent, verbatim, including the 4c
   * `state` rows that have no place in `onLine`/`onStep`. Ignored off win32,
   * where there is no host and no door.
   */
  onHostEvent?: (event: HostEvent) => void;
  /**
   * win32 only: the `fetch` the host's door is asked with. Defaults to
   * `globalThis.fetch` — the platform's own, on the node this package declares
   * (`engines: node >=20`). This exists so the tests can script a host without
   * opening a socket; an app has no reason to pass it.
   */
  fetchImpl?: HostFetch;
}

export interface InstallStep {
  name: string;
  /** What ran, with the token spelled `<redacted>`. Empty for a skipped step. */
  argv: readonly string[];
  status: 'running' | 'ok' | 'skipped';
  detail: string;
}

export interface InstallResult {
  steps: InstallStep[];
  /** The server as its config now describes it. The token is not here; `readLocalConfig()` is. */
  server: { name: string; url: string; configPath: string };
  /** Which release's packs are on this host, and which backend they are for. */
  release: string;
  backend: PackBackend;
  /** `<CRUCIBLE_HOME>/server/bin/crucible`, as the target spells it. */
  crucible: string;
}

/** A 32-byte urlsafe token — the same shape `crucible.config.mint_token` produces. */
export function mintToken(): string {
  return randomBytes(32).toString('base64url');
}

const TAIL_LINES = 40;

interface Plan {
  enableFlags: string[];
  installs: { type: JobType; argv: string[] }[];
}

/** Turn the request into `--enable-*` flags and `crucible install` argv, or refuse by name. */
export function planJobTypes(requests: readonly JobTypeRequest[]): Plan {
  if (requests.length === 0) {
    throw new BootstrapRefusal('bad_job_type', 'jobTypes is empty: a Crucible with no job types serves nothing. Name at least one.');
  }
  const seen = new Set<JobType>();
  const enableFlags: string[] = [];
  const installs: Plan['installs'] = [];
  for (const request of requests) {
    const type = typeof request === 'string' ? request : (request as { type: unknown }).type;
    if (typeof type !== 'string' || !(JOB_TYPES as readonly string[]).includes(type)) {
      throw new BootstrapRefusal('bad_job_type', `unknown job type ${JSON.stringify(type)}; this build knows ${JOB_TYPES.join(', ')}`);
    }
    const jobType = type as JobType;
    if (jobType === 'tts') {
      const engine = typeof request === 'object' ? request.narratorEngine : undefined;
      if (typeof engine !== 'string' || engine.trim() === '') {
        throw new BootstrapRefusal(
          'bad_job_type',
          'tts must name its narrator engine — { type: "tts", narratorEngine: "higgs-v3" } — because cuda-linux has one env per engine',
        );
      }
      if (seen.has('tts')) throw new BootstrapRefusal('bad_job_type', 'tts is listed twice; one narrator engine per install');
      seen.add('tts');
      enableFlags.push('--enable-tts');
      installs.push({ type: 'tts', argv: ['install', 'tts', '--narrator-engine', engine, '--verbose'] });
      continue;
    }
    if (seen.has(jobType)) continue;
    seen.add(jobType);
    enableFlags.push(`--enable-${jobType}`);
    if (INSTALLABLE_JOB_TYPES.includes(jobType)) installs.push({ type: jobType, argv: ['install', jobType, '--verbose'] });
  }
  if (seen.has('denoise') && !seen.has('rvc')) {
    throw new BootstrapRefusal(
      'bad_job_type',
      'denoise shares the rvc env and has no installer of its own (`crucible install rvc` enables both); ask for rvc as well',
    );
  }
  return { enableFlags, installs };
}

/**
 * win32: PHASE15 4.3's two branches, and nothing else.
 *
 * There is no third branch that walks the steps here. A Windows machine
 * installs its Crucible exactly one way — through `crucible host` — so that
 * `install.ps1`, the operator page's engine switch (4.7) and an app's
 * `install()` cannot describe three different installs (PHASE14 4a, "cannot
 * differ").
 *
 * **Why a library posts to a loopback port when there is a whole tasks API.**
 * 4.3 names two callers of the door. The page's `POST /v1/tasks
 * {"type":"engine","target":"wsl"}` is the primary one and goes through the
 * Windows SERVER, which relays the door's events under a task id. This is the
 * other one, and it runs on a machine that has no server yet — the very first
 * install, before there is a page to open or a `/v1/tasks` to post to.
 */
async function installThroughHost(options: InstallOptions, release: string, runner: Runner): Promise<InstallResult> {
  // The one thing this side still does with the job list: refuse a malformed
  // one BY NAME. `{type: 'tts'}` with no narrator engine is the caller's bug,
  // and being told so must not require a host to be installed and answering.
  // The plan itself is thrown away — the host builds its own from the same list.
  planJobTypes(options.jobTypes);

  if (!hostInstalled(runner)) {
    throw new BootstrapRefusal(
      'host_not_installed',
      `there is no Crucible host at ${hostPackDir(runner)} on this machine, and on Windows the host is what installs `
        + 'a Crucible: it walks the WSL state table, raises the two UAC prompts a WSL install needs, and shows the '
        + 'steps in its own window. Run the line below once, then call install() again. '
        + 'It is not run from here on purpose — a library that downloads and elevates an installer from a background '
        + 'call is a dialog nobody asked for.',
      { command: hostInstallCommand(release) },
    );
  }

  return await requestHostInstall(
    {
      release,
      jobTypes: options.jobTypes,
      ...(options.home === undefined ? {} : { home: options.home }),
      ...(options.bind === undefined ? {} : { bind: options.bind }),
      ...(options.onHostEvent === undefined ? {} : { onEvent: options.onHostEvent }),
      ...(options.fetchImpl === undefined ? {} : { fetchImpl: options.fetchImpl }),
      onLine: options.onLine,
      ...(options.onStep === undefined ? {} : { onStep: options.onStep }),
    },
    runner,
  );
}

export async function install(options: InstallOptions, runner: Runner = processRunner()): Promise<InstallResult> {
  const release = options.release ?? BOOTSTRAP_VERSION;
  if (runner.platform === 'win32') return await installThroughHost(options, release, runner);
  // ---------------------------------------------------------------------
  // linux and darwin only, from here down: win32 returned above. Every step,
  // every argv and every refusal below is what it was before PHASE15 — the
  // only thing that went is the distro resolution, which had no answer to give
  // on a machine that IS the server and whose one caller was the win32 arm.
  // ---------------------------------------------------------------------
  const backend = backendFor(runner.platform);
  const target = resolveTarget(runner, undefined);
  const jobs = planJobTypes(options.jobTypes);
  const timeouts = { ...DEFAULT_INSTALL_TIMEOUTS, ...options.timeouts };
  const steps: InstallStep[] = [];
  const done: string[] = [];
  const env = options.home === undefined ? undefined : { CRUCIBLE_HOME: options.home };

  const bind: string[] = [];
  if (options.bind?.host !== undefined) bind.push('--host', options.bind.host);
  if (options.bind?.port !== undefined) bind.push('--port', String(options.bind.port));
  const plan: StepPlan = { enableFlags: jobs.enableFlags, installs: jobs.installs, bind, linger: target.kind === 'wsl' };

  const report = (step: InstallStep): InstallStep => {
    steps.push(step);
    options.onStep?.(step);
    return step;
  };

  const runStep = async (name: string, argv: readonly string[], timeoutMs: number, redacted?: readonly string[]): Promise<void> => {
    const shown = redacted ?? argv;
    const step = report({ name, argv: shown, status: 'running', detail: '' });
    const tail: string[] = [];
    const result = await streamOn(runner, target, argv, {
      timeoutMs,
      ...(env === undefined ? {} : { env }),
      onLine: (line, stream) => {
        tail.push(`${stream === 'stderr' ? '! ' : ''}${line}`);
        if (tail.length > TAIL_LINES) tail.shift();
        options.onLine(line, stream, name);
      },
    });
    if (result.failure !== null || result.code !== 0) {
      const why = result.failure ?? `exited ${result.code}`;
      throw new BootstrapStepFailed(
        name,
        result.code,
        tail,
        [...done],
        `install step "${name}" ${why} inside ${describeTarget(target)}: ${shown.join(' ')}`,
        { detail: tail.join('\n') },
      );
    }
    step.status = 'ok';
    step.detail = `exit 0`;
    done.push(name);
    options.onStep?.(step);
  };

  const configOptions = options.home === undefined ? {} : { home: options.home };
  const values: Partial<Record<RefName, string>> = { release, backend };
  let crucible: string | null = null;
  // Measured by `host-facts`, consumed by `server-pack`. Locals rather than a
  // state object threaded through the walk: the sequence is a sequence, and
  // the one step that reads them is the next one.
  let manifest: Awaited<ReturnType<typeof fetchManifest>> | null = null;
  let guest: Awaited<ReturnType<typeof probeGuest>> | null = null;

  for (const step of installSteps(plan)) {
    switch (step.name) {
      case 'host-facts': {
        guest = await probeGuest(runner, target, options.home);
        refuseMissingTools(target, runner.platform, guest.missingTools);
        values.home = guest.home;
        values.user = guest.user;
        report({
          name: step.name,
          argv: [],
          status: 'ok',
          detail: `${describeTarget(target)}: CRUCIBLE_HOME ${guest.home}, user ${guest.user}, `
            + `${(guest.freeBytes / 1024 ** 3).toFixed(1)} GiB free`
            + `${guest.server === null ? '' : `, server pack ${guest.server.release ?? 'unstamped'}`}`,
        });
        done.push(step.name);

        // The pack fetch needs the manifest, and the manifest is fetched with
        // the GUEST's curl — nothing here reaches the network itself, so a
        // proxy or a VPN inside the distro is the guest's own answer.
        manifest = await fetchManifest(runner, target, release, envpacksUrl(release), timeouts.quickMs);
        break;
      }
      case 'server-pack': {
        if (manifest === null || guest === null) throw new Error('unreachable: host-facts did not run before server-pack');
        const packStep = report({ name: step.name, argv: [], status: 'running', detail: `${SERVER_SUBDIR} pack for ${backend}, release ${release}` });
        const result = await installPack(runner, target, manifest, 'server', {
          release,
          backend,
          home: guest.home,
          freeBytes: guest.freeBytes,
          installed: guest.server,
          timeoutMs: timeouts.packMs,
          onLine: (line, stream) => options.onLine(line, stream, step.name),
        });
        crucible = result.paths.crucible;
        values.crucible = crucible;
        packStep.status = result.skipped ? 'skipped' : 'ok';
        packStep.detail = result.skipped
          ? `${result.paths.dest} is already the ${release} pack (sha ${result.entry.sha256.slice(0, 12)}…)`
          : `unpacked ${result.entry.parts.length} part(s) into ${result.paths.dest} (Python ${result.entry.python})`;
        packStep.argv = result.skipped ? [] : [result.paths.crucible];
        options.onStep?.(packStep);
        if (!result.skipped) done.push(step.name);
        break;
      }
      case 'init': {
        let existing: LocalConfig | null = null;
        try {
          existing = await readLocalConfig(configOptions, runner);
        } catch (err) {
          if (!(err instanceof BootstrapRefusal) || err.code !== 'no_local_config') throw err;
        }
        if (existing !== null) {
          report({ name: 'init', argv: [], status: 'skipped', detail: `config exists at ${existing.configPath}; its token is kept` });
          break;
        }
        if (step.words === null) throw new Error('unreachable: the init step has no argv');
        const token = mintToken();
        const argv = renderArgv(step.words, { ...values, token });
        const redacted = renderArgv(step.words, { ...values, token: '<redacted>' });
        await runStep('init', argv, timeouts[step.timeout], redacted);
        break;
      }
      case 'linger': {
        const linger = await ensureLinger(runner, target, env);
        if (linger !== null) {
          report({ name: 'linger', argv: linger.argv, status: linger.granted ? 'ok' : 'skipped', detail: linger.detail });
          if (linger.granted) done.push('linger');
        }
        break;
      }
      default: {
        if (step.words === null) throw new Error(`unreachable: step ${step.name} has neither argv nor a handler`);
        await runStep(step.name, renderArgv(step.words, values), timeouts[step.timeout]);
      }
    }
  }

  if (crucible === null) throw new Error('unreachable: no server pack after the sequence');
  const config = await readLocalConfig(configOptions, runner);
  return {
    steps,
    server: { name: config.name, url: config.url, configPath: config.configPath },
    release,
    backend,
    crucible,
  };
}
