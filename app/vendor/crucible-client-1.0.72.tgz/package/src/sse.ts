export interface SseFrame {
  readonly lastEventId: string | null;
  readonly event: string | null;
  readonly data: string;
}

const FIELD_SEPARATOR = ':';

export async function* readSseFrames(
  stream: ReadableStream<Uint8Array>,
): AsyncGenerator<SseFrame, void, undefined> {
  const reader = stream.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let eventName: string | null = null;
  let eventId: string | null = null;
  let dataLines: string[] = [];
  let sawData = false;

  const takeFrame = (): SseFrame | null => {
    if (!sawData && eventName === null && eventId === null) return null;
    if (!sawData) {
      eventName = null;
      eventId = null;
      dataLines = [];
      return null;
    }
    const frame: SseFrame = {
      lastEventId: eventId,
      event: eventName,
      data: dataLines.join('\n'),
    };
    eventName = null;
    eventId = null;
    dataLines = [];
    sawData = false;
    return frame;
  };

  try {
    for (;;) {
      const chunk = await reader.read();
      if (chunk.done) break;
      buffer += decoder.decode(chunk.value, { stream: true });

      for (;;) {
        const line = takeLine();
        if (line === null) break;
        if (line === '') {
          const frame = takeFrame();
          if (frame !== null) yield frame;
          continue;
        }
        if (line.startsWith(FIELD_SEPARATOR)) continue;
        const separator = line.indexOf(FIELD_SEPARATOR);
        const name = separator === -1 ? line : line.slice(0, separator);
        let value = separator === -1 ? '' : line.slice(separator + 1);
        if (value.startsWith(' ')) value = value.slice(1);
        switch (name) {
          case 'event':
            eventName = value;
            break;
          case 'data':
            dataLines.push(value);
            sawData = true;
            break;
          case 'id':
            if (!value.includes('\0')) eventId = value;
            break;
          case 'retry':
            break;
          default:
            break;
        }
      }
    }
  } finally {
    reader.releaseLock();
  }

  function takeLine(): string | null {
    for (let index = 0; index < buffer.length; index += 1) {
      const character = buffer[index];
      if (character === '\n') {
        const line = buffer.slice(0, index);
        buffer = buffer.slice(index + 1);
        return line;
      }
      if (character === '\r') {
        const line = buffer.slice(0, index);
        if (index + 1 === buffer.length) return null;
        buffer = buffer.slice(buffer[index + 1] === '\n' ? index + 2 : index + 1);
        return line;
      }
    }
    return null;
  }
}
