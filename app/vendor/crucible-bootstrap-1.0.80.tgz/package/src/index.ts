export { consoleScriptBeside, detectHost, parseNvidiaSmi, pickProbeDistro, WSL_NVIDIA_SMI } from './host.js';
export type { DetectOptions, GpuFacts, HostFacts, WslFacts } from './host.js';

export { install, mintToken, planJobTypes, DEFAULT_INSTALL_TIMEOUTS, INSTALLABLE_JOB_TYPES, JOB_TYPES } from './install.js';
export type { InstallOptions, InstallResult, InstallStep, InstallTimeouts, JobType, JobTypeRequest } from './install.js';

export { compareReleases, latestRelease, LATEST_RELEASE_URL, parseLatestRelease } from './channel.js';

export {
  backendFor,
  HOST_BACKEND,
  releaseAssetUrl,
  RELEASE_REPO,
  wheelAssetName,
  wheelShaAssetName,
  wheelShaUrl,
  wheelUrl,
} from './release.js';
export type { ServerBackend } from './release.js';

export {
  DESKTOP_PACKAGES,
  interpreterFor,
  interpreterUrl,
  SERVER_PYTHON,
  STANDALONE_BASE,
} from './interpreter.js';
export type { StandalonePython } from './interpreter.js';

export {
  CURL_ARGS,
  DOWNLOADS_SUBDIR,
  guestProbeScript,
  installRuntime,
  HOST_SUBDIR,
  probeGuest,
  requireRuntime,
  runtimePaths,
  SERVER_SUBDIR,
  shaArgv,
  STAMP_NAME,
  TAR_ARGS,
} from './runtime.js';
export type { GuestFacts, InstalledRuntime, RuntimeInstallOptions, RuntimeInstallResult, RuntimePaths } from './runtime.js';

export {
  CRUCIBLE_DISTRO,
  crucibleAppData,
  ensureDistro,
  importArgv,
  listDistros,
  readWslConf,
  resolveDistro,
  terminateArgv,
  unregisterArgv,
  writeWslConf,
  WSL_CONF_MARKER,
  WSL_CONF_TEXT,
} from './distro.js';
export type { DistroChoiceOptions, DistroOutcome, EnsureDistroOptions } from './distro.js';

export {
  DECISION_POLL_MS,
  DECISION_WAIT_MS,
  HOST_DOOR_PORT,
  HOST_DOOR_URL,
  HOST_ENTRY_POINT,
  HOST_EVENT_KINDS,
  HOST_INSTALL_EVENTS_PATH,
  HOST_INSTALL_PATH,
  HOST_INSTALL_TARGET,
  TERMINAL_OUTCOME_STATES,
  WSL_OUTCOME_STATES,
  hostConfigPath,
  hostInstallCommand,
  hostInstalled,
  hostRuntimeDir,
  hostToken,
  installStatus,
  requestHostInstall,
  watchInstall,
} from './hostdoor.js';
export type {
  HostDoneData,
  HostDoneStep,
  HostEvent,
  HostUnknownEvent,
  HostEventKind,
  HostEventSinks,
  HostFailedData,
  HostFetch,
  HostInstallOptions,
  HostInstallRequestBody,
  HostLineData,
  HostPresenceData,
  HostProgressData,
  HostStateData,
  HostStepData,
  InstallStatus,
  InstallStatusOptions,
  WatchInstallOptions,
  WslOutcome,
  WslOutcomeState,
} from './hostdoor.js';

export { detectWslState, elevatedArgv, probeArgv, wslStates } from './wsl-states.js';
export type { Evidence, ProbeKey, WslAction, WslState, WslStateDef, WslStateInputs } from './wsl-states.js';

export { installSteps, renderArgv, renderSh, SHELL_VARIABLE } from './steps.js';
export type { RefName, StepDef, StepPlan, Word } from './steps.js';

export { ensureRunning, parseServiceStatus } from './service.js';
export type { EnsureRunningOptions, RunningService, ServiceStatus } from './service.js';

export {
  connectHost,
  CRUCIBLE_HOME_ENV,
  LOCAL_SERVER_NAME,
  localConfigPath,
  parseLocalConfig,
  readLocalConfig,
} from './config.js';
export type { LocalConfig, LocalConfigOptions } from './config.js';

export { health } from './health.js';
export type { ActivityClient, HealthOptions } from './health.js';

export { BootstrapRefusal, BootstrapStepFailed } from './errors.js';
export type { BootstrapRefusalCode, BootstrapRefusalOptions } from './errors.js';

export { decodeWslBytes, incompleteTailBytes, processRunner, segmentWslBytes, splitLines } from './runner.js';
export type { OutputStream, RunOptions, RunResult, Runner, StreamOptions, WslSegment } from './runner.js';

export { guestPathFor, networkPathBehind, parseWslList, shellQuote, toWslPath, wslArgv, wslListArgv, wslRootArgv } from './wsl.js';
export type { WslDistro } from './wsl.js';

export { parseToml, TomlError } from './toml.js';
export type { TomlTable, TomlValue } from './toml.js';

export { BOOTSTRAP_VERSION } from './version.js';
export { readLocalInstallation, localStatus, startLocal, stopLocal, localUninstallCommand, LocalInstallationError } from './local.js';
export type { LocalInstallation, LocalStatus, LocalOptions, LocalCommand, LocalUninstallFlags } from './local.js';
